(function () {
  "use strict";

  const scene = document.getElementById("scene");
  const picker = document.getElementById("model-file");
  const status = document.getElementById("status");
  const statusBar = document.querySelector(".bottom-bar");
  const errorCard = document.getElementById("error-card");
  const defaultModel = "margua.lox";

  let viewer;
  let ui;
  let pendingModelName = "";

  function setStatus(message, state) {
    status.textContent = message;
    statusBar.classList.toggle("is-loading", state === "loading");
    statusBar.classList.toggle("is-ready", state === "ready");
  }

  function showError(message) {
    errorCard.textContent = message;
    errorCard.hidden = false;
  }

  function clearError() {
    errorCard.hidden = true;
    errorCard.textContent = "";
  }

  function loadModel(file) {
    if (!file) return;
    clearError();

    const extension = file.name.split(".").pop().toLowerCase();
    if (!["lox", "3d", "plt"].includes(extension)) {
      showError("Formato non supportato. Scegli un modello .lox, .3d o .plt. Il DXF va prima convertito con cSurvey/Therion.");
      return;
    }

    pendingModelName = file.name;
    ui.loadCave(file);
    setStatus("Caricamento del rilievo…", "loading");
  }

  function loadDefaultModel() {
    pendingModelName = defaultModel;
    clearError();
    setStatus("Caricamento automatico del rilievo…", "loading");

    const modelUrl = new URL("./Surveys/" + defaultModel, document.baseURI);
    fetch(modelUrl)
      .then(function (response) {
        if (!response.ok) {
          throw new Error("il sito ha risposto con codice " + response.status);
        }
        return response.arrayBuffer();
      })
      .then(function (data) {
        if (!data || data.byteLength === 0) {
          throw new Error("il file del rilievo è vuoto");
        }
        ui.loadCave(new File([data], defaultModel, { type: "application/octet-stream" }));
      })
      .catch(function (error) {
        setStatus("Caricamento non riuscito", "idle");
        showError("Non riesco a caricare il rilievo dal sito. Controlla che Surveys/margua.lox sia stato pubblicato insieme alla pagina. " + error.message);
        console.error(error);
      });
  }

  function start() {
    if (!window.CV2 || !window.CV2.CaveViewer || !window.CV2.CaveViewUI) {
      throw new Error("Non trovo il motore CaveView. Controlla che la cartella CaveView sia accanto a index.html.");
    }

    viewer = new CV2.CaveViewer("scene", {
      home: "./CaveView/",
      language: "it",
      surveyDirectory: "./Surveys/",
      terrainDirectory: "./terrain/",
      loadMetadata: true
    });
    ui = new CV2.CaveViewUI(viewer);

    viewer.addEventListener("newCave", function () {
      const modelName = pendingModelName || (picker.files && picker.files[0] ? picker.files[0].name : "Modello caricato");
      setStatus(modelName, "ready");
      clearError();
    });

    viewer.addEventListener("clear", function () {
      setStatus("Nessun modello caricato", "idle");
    });

    document.getElementById("open-model").addEventListener("click", function () { picker.click(); });
    picker.addEventListener("change", function () { loadModel(picker.files[0]); });

    const viewerShell = document.getElementById("viewer");
    viewerShell.addEventListener("dragover", function (event) {
      event.preventDefault();
    }, true);
    viewerShell.addEventListener("drop", function (event) {
      event.preventDefault();
      event.stopPropagation();
      loadModel(event.dataTransfer && event.dataTransfer.files[0]);
    }, true);
    loadDefaultModel();
  }

  try {
    start();
  } catch (error) {
    setStatus("Avvio non riuscito", "idle");
    showError(error.message || "Errore durante l’avvio del visualizzatore.");
    console.error(error);
  }
}());
